  let directorioRoot = document.location.hostname;
  console.log(directorioRoot);
